/*
 * Convert_Assemblytics.h
 *
 *  Created on: May 26, 2016
 *      Author: fsedlaze
 */

#ifndef CONVERT_CONVERT_ASSEMBLYTICS_H_
#define CONVERT_CONVERT_ASSEMBLYTICS_H_


#include "Process_Lumpy.h"

void process_Assemblytics( std::string assemblytics, int minlen, std::string output);



#endif /* CONVERT_CONVERT_ASSEMBLYTICS_H_ */
