/*
 * Convert_Honey_tails.h
 *
 *  Created on: Jun 6, 2016
 *      Author: fsedlaze
 */

#ifndef CONVERT_CONVERT_HONEY_TAILS_H_
#define CONVERT_CONVERT_HONEY_TAILS_H_


#include "Process_Lumpy.h"
void process_Honey( std::string assemblytics, int minlen, std::string output);




#endif /* CONVERT_CONVERT_HONEY_TAILS_H_ */
