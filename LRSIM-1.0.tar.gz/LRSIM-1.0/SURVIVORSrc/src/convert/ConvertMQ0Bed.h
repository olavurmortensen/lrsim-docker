/*
 * ConvertMQ0Bed.h
 *
 *  Created on: Mar 16, 2015
 *      Author: fsedlaze
 */

#ifndef CONVERTMQ0BED_H_
#define CONVERTMQ0BED_H_

#include <string.h>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <stdlib.h>
void comp_mq0bed(std::string cov_file,int border, int cov_tresh);



#endif /* CONVERTMQ0BED_H_ */
