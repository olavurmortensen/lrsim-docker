/*
 * Convert_Bionano.h
 *
 *  Created on: Jun 20, 2016
 *      Author: fsedlaze
 */

#ifndef CONVERT_CONVERT_BIONANO_H_
#define CONVERT_CONVERT_BIONANO_H_
#include "Process_Lumpy.h"
void process_Bionano(std::string bionano, std::string output);

#endif /* CONVERT_CONVERT_BIONANO_H_ */
