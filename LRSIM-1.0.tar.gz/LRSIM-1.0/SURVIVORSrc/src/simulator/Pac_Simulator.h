/*
 * Pac_Simulator.h
 *
 *  Created on: Feb 1, 2016
 *      Author: fsedlaze
 */

#ifndef SIMULATOR_PAC_SIMULATOR_H_
#define SIMULATOR_PAC_SIMULATOR_H_

#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <stdlib.h>
#include <sstream>
void simulate_pac(std::string genome,std::string out);

#endif /* SIMULATOR_PAC_SIMULATOR_H_ */
