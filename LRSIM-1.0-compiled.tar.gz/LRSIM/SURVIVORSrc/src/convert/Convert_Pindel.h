/*
 * Convert_Pindel.h
 *
 *  Created on: Mar 3, 2015
 *      Author: fsedlaze
 */

#ifndef CONVERT_PINDEL_H_
#define CONVERT_PINDEL_H_

#include "Process_Lumpy.h"

void process_Pindel( std::string pindel_vcf,int min_support, int min_length,std::string output);


#endif /* CONVERT_PINDEL_H_ */
